 

# Proyecto Final Individual

Indice 

[0.Agradecimientos](./agra.md)

[1.Introducción](./intro.md)

[2.Proyecto](./project.md)

[3.Herramientas](./tools.md)

[4.Herramientas secundarias](./tools2.md)

[5.Componente](./component.md)

[6.Problemas](./problems.md)

[7.Miscelanea](./misc.md)

[8.WebGrafía](./web.md)
