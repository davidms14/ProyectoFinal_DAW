
# 8.WebGrafía

-	https://github.com/Lemoncode  - Braulio Diez - 2019 – Página de LemonCode.
-	https://www.npmjs.com/package/typescript  - TypeScript – 2019 – NPM TS.
-	https://www.typescriptlang.org/  - Microsoft – 2012/2019 – Página oficial TS.
-	https://reactjs.org/  - Facebook Inc. - 2019 – Página oficial de React.
-	https://www.npmjs.com/package/react  - Colaboradores - 2019 – NPM React.
-	https://www.npmjs.com/package/redux  - Colaboradores - 2018 – NPM Redux.
-	https://redux.js.org/  - Dan Abramov and the Redux documentation authors – 2015 - Página oficial Redux.
-	https://www.npmjs.com/package/jest  - Colaboradores – 2019 – NPM JEST.
-	https://jestjs.io/  - Facebook Inc. – 2019 – Página oficial de Jest.
-	https://www.npmjs.com/package/webpack  - Tobias Koppers / Johannes Ewald - Sean T. Larkin - Kees Kluskens – 2019 – NPM WebPack.
-	https://github.com/webpack/webpack  - Tobias Koppers / Johannes Ewald - Sean T. Larkin - Kees Kluskens – 2019 – GitHub oficial de WebPack.
-	https://nodejs.org/es/  - Node.js Foundation – 2019 – Página para la descarga de NodeJS.
-	https://github.com/airbnb/enzyme  - ljharb - 2019 – Github de instalación y documentación de Enzyme. 
-	https://www.npmjs.com/package/i18n  - mashpie – 2016 – NPM i18next.
-	https://github.com/mashpie/i18n-node  - mashpie - 2016 – GitHub de i18next.
-	https://www.npmjs.com/package/markdown  - ashb / dom – 2016 – NPM markDown.
-	https://github.com/evilstreak/markdown-js#readme  - ashb – 2013 – GitHub MarkDown.
-	https://www.npmjs.com/package/moment  - Colaboradores – 2019 – NPM Moment.
-	http://momentjs.com/  - MIT license – 2019 – Página de documentación de moment.
-	https://github.com/typescript-eslint/typescript-eslint  - nevir / bradzacher – 2019 -Explicación de esLint.
-	https://www.npmjs.com/package/eslint-plugin-react  - ljharb / yannickr – 2019 – NPM esLint.
-	https://www.npmjs.com/package/eslint  - esLint / ivolodin / nzakas – 2019 – NPM esLint.
-	https://www.npmjs.com/  - NPM – 2019 – NPM.
-	https://products.office.com/es-es/home?ms.url=office365com&rtc=1  - Microsoft – 2019 – Página oficial para office 365.
-	https://code.visualstudio.com/  - Microsoft – 2019 – Página para descargar office 365.
-	https://github.com/gajus/eslint-plugin-jsdoc#eslint-plugin-jsdoc-installation  - brettz9 – 2019 – Documentación de JSDOC


