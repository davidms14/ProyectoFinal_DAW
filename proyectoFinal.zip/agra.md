
# 0. Agradecimientos

En primer lugar, agradecer al instituto CIP FP Batoy por darme la oportunidad de realizar las prácticas (las que creo, serán las últimas) y sobre todo haberme formado para poder realizar tanto estas, como cualquier futuro trabajo que se pueda presentar en el mundo laboral.

En segundo lugar, también a la empresa Aitex la posibilidad de realizar las prácticas en sus instalaciones y haberme formado en las tecnologías y herramientas que aquí se utilizan para desarrollar este proyecto.

Agradecimientos también para mi tutor en la empresa Amando Olcina, responsable del Área de Desarrollo, por su dedicación y su tiempo en conseguir que entendiera y aprendiera todos y cada uno de los conceptos aprendidos, así como su ayuda durante la realización del proyecto.

Finalmente agradecer también a Gonzalo Cambra, integrante del equipo del Área de Desarrollo, la ayuda brindada durante la ejecución del proyecto, así como su apoyo y su paciencia para explicarme las dudas y situaciones que iban surgiéndome.

Han conseguido hacer de estas prácticas las mejores hasta la fecha y que junto a todo el Equipo de Sistemas y Desarrollo, han logrado integrarme como uno más del grupo.  
