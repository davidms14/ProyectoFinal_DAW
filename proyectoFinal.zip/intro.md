
# 1. Introducción

Para empezar, me gustaría mencionar que este no era el primer proyecto que yo tenía asignado de cara a la realización de las prácticas. La idea que se pretendía llevar a cabo como primera opción consistía en realizar uno de los proyectos proporcionados por el profesorado. Este trataba de llevar adelante la creación de una aplicación que permitiera a los usuarios de la sección de Hostelería del instituto efectuar una gestión de los proveedores que proporcionan diferentes productos a su departamento.

De la misma forma que ha cambiado el objetivo del proyecto, las herramientas a utilizar en este también ya que iba a utilizarse Laravel para su realización. 

Debido a que en la empresa se me permitió trabajar con las tecnologías empleadas en esta, decidí no llevar acabo lo mencionado anteriormente e iniciar un proyecto diferente.




