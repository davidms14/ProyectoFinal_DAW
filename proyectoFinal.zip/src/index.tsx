import * as ReactDOM from 'react-dom';
import * as React from 'react';
import Tile from './components/tile';
import './i18n';

ReactDOM.render(<Tile />, document.getElementById('sample'));
